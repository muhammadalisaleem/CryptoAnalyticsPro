﻿namespace CAP
{
    partial class MarketTrends
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MarketTrends));
            panel1 = new Panel();
            button5 = new Button();
            button4 = new Button();
            button3 = new Button();
            button1 = new Button();
            textBox1 = new TextBox();
            button2 = new Button();
            pictureBox1 = new PictureBox();
            textBox2 = new TextBox();
            panel2 = new Panel();
            textBox13 = new TextBox();
            comboBox1 = new ComboBox();
            textBox12 = new TextBox();
            panel3 = new Panel();
            label6 = new Label();
            label5 = new Label();
            label4 = new Label();
            label3 = new Label();
            label2 = new Label();
            label1 = new Label();
            numericUpDown1 = new NumericUpDown();
            comboBox2 = new ComboBox();
            panel4 = new Panel();
            textBox18 = new TextBox();
            button7 = new Button();
            textBox16 = new TextBox();
            textBox15 = new TextBox();
            textBox14 = new TextBox();
            textBox10 = new TextBox();
            button6 = new Button();
            textBox11 = new TextBox();
            textBox9 = new TextBox();
            textBox8 = new TextBox();
            textBox7 = new TextBox();
            textBox6 = new TextBox();
            textBox4 = new TextBox();
            textBox3 = new TextBox();
            textBox5 = new TextBox();
            contextMenuStrip1 = new ContextMenuStrip(components);
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            panel2.SuspendLayout();
            panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)numericUpDown1).BeginInit();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.BackColor = Color.FromArgb(35, 35, 35);
            panel1.Controls.Add(button5);
            panel1.Controls.Add(button4);
            panel1.Controls.Add(button3);
            panel1.Controls.Add(button1);
            panel1.Controls.Add(textBox1);
            panel1.Controls.Add(button2);
            panel1.Controls.Add(pictureBox1);
            panel1.Location = new Point(-2, -1);
            panel1.Margin = new Padding(3, 4, 3, 4);
            panel1.Name = "panel1";
            panel1.Size = new Size(209, 611);
            panel1.TabIndex = 3;
            // 
            // button5
            // 
            button5.BackColor = Color.FromArgb(0, 64, 64);
            button5.Cursor = Cursors.Hand;
            button5.FlatStyle = FlatStyle.Popup;
            button5.ForeColor = SystemColors.ControlText;
            button5.Location = new Point(61, 529);
            button5.Margin = new Padding(3, 4, 3, 4);
            button5.Name = "button5";
            button5.Size = new Size(86, 31);
            button5.TabIndex = 2;
            button5.Text = "Signout";
            button5.UseVisualStyleBackColor = false;
            button5.Click += button5_Click;
            // 
            // button4
            // 
            button4.BackColor = Color.FromArgb(20, 20, 20);
            button4.Cursor = Cursors.Hand;
            button4.FlatStyle = FlatStyle.Popup;
            button4.ForeColor = SystemColors.Control;
            button4.Location = new Point(31, 400);
            button4.Margin = new Padding(3, 4, 3, 4);
            button4.Name = "button4";
            button4.Size = new Size(157, 48);
            button4.TabIndex = 2;
            button4.Text = "Market Trends";
            button4.UseVisualStyleBackColor = false;
            button4.Click += button4_Click;
            // 
            // button3
            // 
            button3.BackColor = Color.FromArgb(20, 20, 20);
            button3.Cursor = Cursors.Hand;
            button3.FlatStyle = FlatStyle.Popup;
            button3.ForeColor = SystemColors.Control;
            button3.Location = new Point(31, 331);
            button3.Margin = new Padding(3, 4, 3, 4);
            button3.Name = "button3";
            button3.Size = new Size(157, 48);
            button3.TabIndex = 2;
            button3.Text = "Trade History";
            button3.UseVisualStyleBackColor = false;
            button3.Click += button3_Click;
            // 
            // button1
            // 
            button1.BackColor = Color.FromArgb(20, 20, 20);
            button1.Cursor = Cursors.Hand;
            button1.FlatStyle = FlatStyle.Popup;
            button1.ForeColor = SystemColors.Control;
            button1.Location = new Point(31, 184);
            button1.Margin = new Padding(3, 4, 3, 4);
            button1.Name = "button1";
            button1.Size = new Size(157, 48);
            button1.TabIndex = 2;
            button1.Text = "Dashboard";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // textBox1
            // 
            textBox1.BackColor = Color.FromArgb(35, 35, 35);
            textBox1.BorderStyle = BorderStyle.None;
            textBox1.Enabled = false;
            textBox1.Font = new Font("Agency FB", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            textBox1.ForeColor = SystemColors.Control;
            textBox1.Location = new Point(41, 116);
            textBox1.Margin = new Padding(3, 4, 3, 4);
            textBox1.Name = "textBox1";
            textBox1.ReadOnly = true;
            textBox1.Size = new Size(127, 24);
            textBox1.TabIndex = 2;
            textBox1.Text = "Crypto Analytics Pro";
            // 
            // button2
            // 
            button2.BackColor = Color.FromArgb(20, 20, 20);
            button2.Cursor = Cursors.Hand;
            button2.FlatStyle = FlatStyle.Popup;
            button2.ForeColor = SystemColors.Control;
            button2.Location = new Point(31, 255);
            button2.Margin = new Padding(3, 4, 3, 4);
            button2.Name = "button2";
            button2.Size = new Size(157, 48);
            button2.TabIndex = 2;
            button2.Text = "Asset Management";
            button2.UseVisualStyleBackColor = false;
            button2.Click += button2_Click;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(47, 4);
            pictureBox1.Margin = new Padding(3, 4, 3, 4);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(114, 109);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 2;
            pictureBox1.TabStop = false;
            // 
            // textBox2
            // 
            textBox2.BackColor = Color.FromArgb(50, 50, 50);
            textBox2.BorderStyle = BorderStyle.None;
            textBox2.Enabled = false;
            textBox2.Font = new Font("Segoe UI Semibold", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            textBox2.ForeColor = SystemColors.Control;
            textBox2.Location = new Point(235, 16);
            textBox2.Margin = new Padding(3, 4, 3, 4);
            textBox2.Name = "textBox2";
            textBox2.ReadOnly = true;
            textBox2.Size = new Size(222, 40);
            textBox2.TabIndex = 4;
            textBox2.Text = "Market Trends";
            // 
            // panel2
            // 
            panel2.BackColor = Color.FromArgb(35, 35, 35);
            panel2.Controls.Add(textBox13);
            panel2.Controls.Add(comboBox1);
            panel2.Controls.Add(textBox12);
            panel2.Controls.Add(panel3);
            panel2.Controls.Add(numericUpDown1);
            panel2.Controls.Add(comboBox2);
            panel2.Controls.Add(panel4);
            panel2.Controls.Add(textBox18);
            panel2.Controls.Add(button7);
            panel2.Controls.Add(textBox16);
            panel2.Controls.Add(textBox15);
            panel2.Controls.Add(textBox14);
            panel2.Controls.Add(textBox10);
            panel2.Controls.Add(button6);
            panel2.Controls.Add(textBox11);
            panel2.Controls.Add(textBox9);
            panel2.Controls.Add(textBox8);
            panel2.Controls.Add(textBox7);
            panel2.Controls.Add(textBox6);
            panel2.Controls.Add(textBox4);
            panel2.Controls.Add(textBox3);
            panel2.Controls.Add(textBox5);
            panel2.Location = new Point(235, 81);
            panel2.Margin = new Padding(3, 4, 3, 4);
            panel2.Name = "panel2";
            panel2.Size = new Size(665, 477);
            panel2.TabIndex = 5;
            // 
            // textBox13
            // 
            textBox13.BackColor = Color.FromArgb(35, 35, 35);
            textBox13.BorderStyle = BorderStyle.None;
            textBox13.Enabled = false;
            textBox13.ForeColor = SystemColors.Control;
            textBox13.Location = new Point(75, 191);
            textBox13.Margin = new Padding(3, 4, 3, 4);
            textBox13.Name = "textBox13";
            textBox13.ReadOnly = true;
            textBox13.Size = new Size(100, 20);
            textBox13.TabIndex = 34;
            textBox13.Text = "Coin Name:";
            // 
            // comboBox1
            // 
            comboBox1.FlatStyle = FlatStyle.Popup;
            comboBox1.FormattingEnabled = true;
            comboBox1.Items.AddRange(new object[] { "Bitcoin", "Ethereum", "Tether", "Pepe", "Ethena", "Solana", "Tron", "Dogecoin", "Cardano", "Litecoin" });
            comboBox1.Location = new Point(193, 187);
            comboBox1.Margin = new Padding(3, 4, 3, 4);
            comboBox1.Name = "comboBox1";
            comboBox1.Size = new Size(167, 28);
            comboBox1.TabIndex = 33;
            comboBox1.SelectedIndexChanged += comboBox1_SelectedIndexChanged;
            // 
            // textBox12
            // 
            textBox12.BorderStyle = BorderStyle.None;
            textBox12.Location = new Point(193, 151);
            textBox12.Margin = new Padding(3, 4, 3, 4);
            textBox12.Name = "textBox12";
            textBox12.Size = new Size(168, 20);
            textBox12.TabIndex = 32;
            textBox12.TextChanged += textBox12_TextChanged;
            // 
            // panel3
            // 
            panel3.BackColor = Color.FromArgb(20, 20, 20);
            panel3.Controls.Add(label6);
            panel3.Controls.Add(label5);
            panel3.Controls.Add(label4);
            panel3.Controls.Add(label3);
            panel3.Controls.Add(label2);
            panel3.Controls.Add(label1);
            panel3.Location = new Point(382, 13);
            panel3.Margin = new Padding(3, 4, 3, 4);
            panel3.Name = "panel3";
            panel3.Size = new Size(270, 296);
            panel3.TabIndex = 20;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Agency FB", 10.5F, FontStyle.Bold);
            label6.ForeColor = SystemColors.Control;
            label6.Location = new Point(21, 245);
            label6.Name = "label6";
            label6.Size = new Size(121, 22);
            label6.TabIndex = 21;
            label6.Text = "Risk Reward Ratio:";
            label6.Click += label6_Click;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Agency FB", 10.5F, FontStyle.Bold);
            label5.ForeColor = SystemColors.Control;
            label5.Location = new Point(21, 24);
            label5.Name = "label5";
            label5.Size = new Size(97, 22);
            label5.TabIndex = 20;
            label5.Text = "Current Price: ";
            label5.Click += label5_Click_1;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Agency FB", 10.5F, FontStyle.Bold);
            label4.ForeColor = SystemColors.Control;
            label4.Location = new Point(21, 196);
            label4.Name = "label4";
            label4.Size = new Size(96, 22);
            label4.TabIndex = 19;
            label4.Text = "Potential Profit:";
            label4.Click += label4_Click;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Agency FB", 10.5F, FontStyle.Bold);
            label3.ForeColor = SystemColors.Control;
            label3.Location = new Point(21, 169);
            label3.Name = "label3";
            label3.Size = new Size(93, 22);
            label3.TabIndex = 18;
            label3.Text = "Potential Loss:";
            label3.Click += label3_Click;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Agency FB", 10.5F, FontStyle.Bold);
            label2.ForeColor = SystemColors.Control;
            label2.Location = new Point(21, 113);
            label2.Name = "label2";
            label2.Size = new Size(112, 22);
            label2.TabIndex = 17;
            label2.Text = "Take-Profit Price:";
            label2.Click += label2_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Cursor = Cursors.No;
            label1.Font = new Font("Agency FB", 10.5F, FontStyle.Bold);
            label1.ForeColor = SystemColors.Control;
            label1.Location = new Point(21, 85);
            label1.Name = "label1";
            label1.Size = new Size(103, 22);
            label1.TabIndex = 16;
            label1.Text = "Stop-loss Price:";
            label1.Click += label1_Click;
            // 
            // numericUpDown1
            // 
            numericUpDown1.BorderStyle = BorderStyle.None;
            numericUpDown1.Location = new Point(338, 377);
            numericUpDown1.Margin = new Padding(3, 4, 3, 4);
            numericUpDown1.Maximum = new decimal(new int[] { 1000000, 0, 0, 0 });
            numericUpDown1.Name = "numericUpDown1";
            numericUpDown1.Size = new Size(104, 23);
            numericUpDown1.TabIndex = 31;
            numericUpDown1.ValueChanged += numericUpDown1_ValueChanged;
            // 
            // comboBox2
            // 
            comboBox2.FlatStyle = FlatStyle.Popup;
            comboBox2.FormattingEnabled = true;
            comboBox2.Items.AddRange(new object[] { "Above", "Below" });
            comboBox2.Location = new Point(557, 375);
            comboBox2.Margin = new Padding(3, 4, 3, 4);
            comboBox2.Name = "comboBox2";
            comboBox2.Size = new Size(94, 28);
            comboBox2.TabIndex = 30;
            comboBox2.SelectedIndexChanged += comboBox2_SelectedIndexChanged;
            // 
            // panel4
            // 
            panel4.BackColor = Color.FromArgb(50, 50, 50);
            panel4.Location = new Point(0, 317);
            panel4.Margin = new Padding(3, 4, 3, 4);
            panel4.Name = "panel4";
            panel4.Size = new Size(665, 13);
            panel4.TabIndex = 22;
            // 
            // textBox18
            // 
            textBox18.BackColor = Color.FromArgb(35, 35, 35);
            textBox18.BorderStyle = BorderStyle.None;
            textBox18.Enabled = false;
            textBox18.ForeColor = SystemColors.Control;
            textBox18.Location = new Point(483, 379);
            textBox18.Margin = new Padding(3, 4, 3, 4);
            textBox18.Name = "textBox18";
            textBox18.ReadOnly = true;
            textBox18.Size = new Size(66, 20);
            textBox18.TabIndex = 29;
            textBox18.Text = "Condition:";
            // 
            // button7
            // 
            button7.BackColor = Color.Maroon;
            button7.Cursor = Cursors.Hand;
            button7.FlatStyle = FlatStyle.Popup;
            button7.ForeColor = SystemColors.Control;
            button7.Location = new Point(233, 423);
            button7.Margin = new Padding(3, 4, 3, 4);
            button7.Name = "button7";
            button7.Size = new Size(179, 33);
            button7.TabIndex = 28;
            button7.Text = "Set Alert";
            button7.UseVisualStyleBackColor = false;
            button7.Click += button7_Click;
            // 
            // textBox16
            // 
            textBox16.BackColor = Color.FromArgb(35, 35, 35);
            textBox16.BorderStyle = BorderStyle.None;
            textBox16.Enabled = false;
            textBox16.ForeColor = SystemColors.Control;
            textBox16.Location = new Point(247, 379);
            textBox16.Margin = new Padding(3, 4, 3, 4);
            textBox16.Name = "textBox16";
            textBox16.ReadOnly = true;
            textBox16.Size = new Size(114, 20);
            textBox16.TabIndex = 26;
            textBox16.Text = "Target Price:";
            // 
            // textBox15
            // 
            textBox15.BorderStyle = BorderStyle.None;
            textBox15.Location = new Point(107, 379);
            textBox15.Margin = new Padding(3, 4, 3, 4);
            textBox15.Name = "textBox15";
            textBox15.Size = new Size(114, 20);
            textBox15.TabIndex = 25;
            textBox15.TextChanged += textBox15_TextChanged;
            // 
            // textBox14
            // 
            textBox14.BackColor = Color.FromArgb(35, 35, 35);
            textBox14.BorderStyle = BorderStyle.None;
            textBox14.Enabled = false;
            textBox14.ForeColor = SystemColors.Control;
            textBox14.Location = new Point(21, 379);
            textBox14.Margin = new Padding(3, 4, 3, 4);
            textBox14.Name = "textBox14";
            textBox14.ReadOnly = true;
            textBox14.Size = new Size(80, 20);
            textBox14.TabIndex = 24;
            textBox14.Text = "Enter Coin:";
            // 
            // textBox10
            // 
            textBox10.BackColor = Color.FromArgb(35, 35, 35);
            textBox10.BorderStyle = BorderStyle.None;
            textBox10.Font = new Font("Segoe UI Semibold", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            textBox10.ForeColor = SystemColors.Control;
            textBox10.Location = new Point(21, 333);
            textBox10.Margin = new Padding(3, 4, 3, 4);
            textBox10.Name = "textBox10";
            textBox10.Size = new Size(114, 32);
            textBox10.TabIndex = 23;
            textBox10.Text = "Alerts";
            textBox10.TextChanged += textBox10_TextChanged;
            // 
            // button6
            // 
            button6.BackColor = Color.Green;
            button6.Cursor = Cursors.Hand;
            button6.FlatStyle = FlatStyle.Popup;
            button6.Location = new Point(89, 257);
            button6.Margin = new Padding(3, 4, 3, 4);
            button6.Name = "button6";
            button6.Size = new Size(272, 31);
            button6.TabIndex = 15;
            button6.Text = "Suggest SL/TP";
            button6.UseVisualStyleBackColor = false;
            button6.Click += button6_Click;
            // 
            // textBox11
            // 
            textBox11.BorderStyle = BorderStyle.None;
            textBox11.Location = new Point(193, 116);
            textBox11.Margin = new Padding(3, 4, 3, 4);
            textBox11.Name = "textBox11";
            textBox11.Size = new Size(168, 20);
            textBox11.TabIndex = 14;
            textBox11.TextChanged += textBox11_TextChanged;
            // 
            // textBox9
            // 
            textBox9.BorderStyle = BorderStyle.None;
            textBox9.Location = new Point(193, 85);
            textBox9.Margin = new Padding(3, 4, 3, 4);
            textBox9.Name = "textBox9";
            textBox9.Size = new Size(168, 20);
            textBox9.TabIndex = 12;
            textBox9.TextChanged += textBox9_TextChanged;
            // 
            // textBox8
            // 
            textBox8.BackColor = Color.FromArgb(35, 35, 35);
            textBox8.BorderStyle = BorderStyle.None;
            textBox8.Enabled = false;
            textBox8.Font = new Font("Segoe UI Semibold", 9F, FontStyle.Bold);
            textBox8.ForeColor = SystemColors.Control;
            textBox8.Location = new Point(75, 116);
            textBox8.Margin = new Padding(3, 4, 3, 4);
            textBox8.Name = "textBox8";
            textBox8.ReadOnly = true;
            textBox8.Size = new Size(109, 20);
            textBox8.TabIndex = 11;
            textBox8.Text = "Take Profit (%):";
            // 
            // textBox7
            // 
            textBox7.BackColor = Color.FromArgb(35, 35, 35);
            textBox7.BorderStyle = BorderStyle.None;
            textBox7.Enabled = false;
            textBox7.Font = new Font("Segoe UI Semibold", 9F, FontStyle.Bold);
            textBox7.ForeColor = SystemColors.Control;
            textBox7.Location = new Point(75, 151);
            textBox7.Margin = new Padding(3, 4, 3, 4);
            textBox7.Name = "textBox7";
            textBox7.ReadOnly = true;
            textBox7.Size = new Size(87, 20);
            textBox7.TabIndex = 10;
            textBox7.Text = "Investment:";
            textBox7.TextChanged += textBox7_TextChanged;
            // 
            // textBox6
            // 
            textBox6.BackColor = Color.FromArgb(35, 35, 35);
            textBox6.BorderStyle = BorderStyle.None;
            textBox6.Enabled = false;
            textBox6.Font = new Font("Segoe UI Semibold", 9F, FontStyle.Bold);
            textBox6.ForeColor = SystemColors.Control;
            textBox6.Location = new Point(75, 85);
            textBox6.Margin = new Padding(3, 4, 3, 4);
            textBox6.Name = "textBox6";
            textBox6.ReadOnly = true;
            textBox6.Size = new Size(100, 20);
            textBox6.TabIndex = 9;
            textBox6.Text = "Stop Loss (%):";
            // 
            // textBox4
            // 
            textBox4.BackColor = Color.FromArgb(35, 35, 35);
            textBox4.BorderStyle = BorderStyle.None;
            textBox4.Enabled = false;
            textBox4.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold);
            textBox4.ForeColor = SystemColors.Control;
            textBox4.Location = new Point(25, 13);
            textBox4.Margin = new Padding(3, 4, 3, 4);
            textBox4.Name = "textBox4";
            textBox4.ReadOnly = true;
            textBox4.Size = new Size(173, 27);
            textBox4.TabIndex = 8;
            textBox4.Text = "SL/TP Calculator";
            textBox4.TextChanged += textBox4_TextChanged_1;
            // 
            // textBox3
            // 
            textBox3.BorderStyle = BorderStyle.None;
            textBox3.Location = new Point(193, 55);
            textBox3.Margin = new Padding(3, 4, 3, 4);
            textBox3.Name = "textBox3";
            textBox3.Size = new Size(168, 20);
            textBox3.TabIndex = 0;
            textBox3.TextChanged += textBox3_TextChanged;
            // 
            // textBox5
            // 
            textBox5.BackColor = Color.FromArgb(35, 35, 35);
            textBox5.BorderStyle = BorderStyle.None;
            textBox5.Enabled = false;
            textBox5.Font = new Font("Segoe UI Semibold", 9F, FontStyle.Bold);
            textBox5.ForeColor = SystemColors.Control;
            textBox5.Location = new Point(75, 56);
            textBox5.Margin = new Padding(3, 4, 3, 4);
            textBox5.Name = "textBox5";
            textBox5.ReadOnly = true;
            textBox5.Size = new Size(100, 20);
            textBox5.TabIndex = 7;
            textBox5.Text = "Entry Price:";
            // 
            // contextMenuStrip1
            // 
            contextMenuStrip1.ImageScalingSize = new Size(20, 20);
            contextMenuStrip1.Name = "contextMenuStrip1";
            contextMenuStrip1.Size = new Size(61, 4);
            // 
            // MarketTrends
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(50, 50, 50);
            ClientSize = new Size(914, 575);
            Controls.Add(panel2);
            Controls.Add(textBox2);
            Controls.Add(panel1);
            ForeColor = SystemColors.Control;
            FormBorderStyle = FormBorderStyle.None;
            Margin = new Padding(3, 4, 3, 4);
            Name = "MarketTrends";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Form1";
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            panel3.ResumeLayout(false);
            panel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)numericUpDown1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Panel panel1;
        private Button button5;
        private Button button4;
        private Button button3;
        private Button button1;
        private TextBox textBox1;
        private Button button2;
        private PictureBox pictureBox1;
        private TextBox textBox2;
        private Panel panel2;
        private TextBox textBox3;
        private TextBox textBox4;
        private TextBox textBox5;
        private TextBox textBox11;
        private TextBox textBox9;
        private TextBox textBox8;
        private TextBox textBox7;
        private TextBox textBox6;
        private Label label2;
        private Label label1;
        private Button button6;
        private Panel panel3;
        private Panel panel4;
        private TextBox textBox10;
        private TextBox textBox16;
        private TextBox textBox15;
        private TextBox textBox14;
        private ContextMenuStrip contextMenuStrip1;
        private Button button7;
        private TextBox textBox18;
        private ComboBox comboBox2;
        private NumericUpDown numericUpDown1;
        private Label label4;
        private Label label3;
        private TextBox textBox12;
        private TextBox textBox13;
        private ComboBox comboBox1;
        private Label label5;
        private Label label6;
    }
}